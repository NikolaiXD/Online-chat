﻿#include <iostream>
#include <string>
#include <vector>
#include <WinSock2.h>
#include <thread>
#include <mutex>

#include "User.h"
#include "Message.h"

#pragma comment(lib, "ws2_32.lib")

using namespace std;

const int PORT = 8080;
const int BUFFER_SIZE = 1024;

vector<SOCKET> clientSockets;
mutex mtx; // Mutex для обеспечения потокобезопасности

void sendMessageToAllClients(const string& message, sockaddr_in senderAddr) {
    lock_guard<mutex> guard(mtx);
    for (SOCKET clientSocket : clientSockets) {
        sendto(clientSocket, message.c_str(), message.size(), 0, (struct sockaddr*)&senderAddr, sizeof(senderAddr));
    }
}

void clientHandler(SOCKET clientSocket, sockaddr_in clientAddr) {
    char buffer[BUFFER_SIZE];
    while (true) {
        int bytesReceived = recvfrom(clientSocket, buffer, BUFFER_SIZE, 0, NULL, NULL);
        if (bytesReceived == SOCKET_ERROR) {
            cerr << "Error receiving message." << endl;
            break;
        }
        buffer[bytesReceived] = '\0';
        string receivedMessage(buffer);

        // Обработка полученного сообщения
        cout << "Received message from client: " << receivedMessage << endl;

        // Отправка ответа клиенту
        string responseMessage = "Message received successfully";
        int bytesSent = sendto(clientSocket, responseMessage.c_str(), responseMessage.size(), 0, (struct sockaddr*)&clientAddr, sizeof(clientAddr));
        if (bytesSent == SOCKET_ERROR) {
            cerr << "Error sending response." << endl;
        }
    }
}

int main() {
    WSADATA wsaData;
    WSAStartup(MAKEWORD(2, 2), &wsaData);

    SOCKET serverSocket;
    struct sockaddr_in serverAddr, clientAddr;
    int clientAddrSize = sizeof(clientAddr);

    // Создание сокета
    serverSocket = socket(AF_INET, SOCK_DGRAM, 0);
    if (serverSocket == INVALID_SOCKET) {
        cerr << "Error creating socket: " << WSAGetLastError() << endl;
        WSACleanup();
        return 1;
    }

    // Настройка адреса сервера
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(PORT);
    serverAddr.sin_addr.s_addr = INADDR_ANY;

    // Привязка сокета к адресу
    if (bind(serverSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
        cerr << "Error binding socket: " << WSAGetLastError() << endl;
        closesocket(serverSocket);
        WSACleanup();
        return 1;
    }

    cout << "Server started, waiting for connections..." << endl;

    // Получение сообщений и обработка их
    while (true) {
        int bytesReceived = recvfrom(serverSocket, NULL, 0, 0, (struct sockaddr*)&clientAddr, &clientAddrSize);
        if (bytesReceived == SOCKET_ERROR) {
            cerr << "Error receiving message." << endl;
            continue;
        }

        {
            lock_guard<mutex> guard(mtx);
            clientSockets.push_back(serverSocket);
        }

        cout << "New client connected" << endl;

        // Обработка клиента в отдельном потоке
        thread(clientHandler, serverSocket, clientAddr).detach();
    }

    closesocket(serverSocket);
    WSACleanup();

    return 0;
}