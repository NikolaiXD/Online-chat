﻿#include <iostream>
#include <string>
#include <WinSock2.h>
#include <WS2tcpip.h> // for InetPton

#pragma comment(lib, "ws2_32.lib")

using namespace std;

const int BUFFER_SIZE = 1024;

void clientMain(const char* serverIp, int port) {
    WSADATA wsaData;
    WSAStartup(MAKEWORD(2, 2), &wsaData);

    SOCKET clientSocket;
    struct sockaddr_in serverAddr;
    char buffer[BUFFER_SIZE];

    // Create socket
    clientSocket = socket(AF_INET, SOCK_DGRAM, 0);
    if (clientSocket == INVALID_SOCKET) {
        cerr << "Error creating socket: " << WSAGetLastError() << endl;
        WSACleanup();
        return;
    }

    // Set up server address
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(port);
    inet_pton(AF_INET, serverIp, &serverAddr.sin_addr);

    // Send and receive messages
    while (true) {
        string message;
        cout << "Enter message: ";
        getline(cin, message);

        // Send message
        int bytesSent = sendto(clientSocket, message.c_str(), message.size(), 0, (struct sockaddr*)&serverAddr, sizeof(serverAddr));
        if (bytesSent == SOCKET_ERROR) {
            cerr << "Error sending message." << endl;
        }
        else {
            cout << "Message sent successfully." << endl;

            // Receive response from server
            int bytesReceived = recvfrom(clientSocket, buffer, BUFFER_SIZE, 0, NULL, NULL);
            if (bytesReceived == SOCKET_ERROR) {
                cerr << "Error receiving response from server." << endl;
            }
            else {
                buffer[bytesReceived] = '\0';
                cout << "Response from server: " << buffer << endl;
            }
        }
    }

    closesocket(clientSocket);
    WSACleanup();
}

int main(int argc, char* argv[]) {
    if (argc != 3) {
        cerr << "Usage: " << argv[0] << " <server_ip> <port>" << endl;
        return 1;
    }

    const char* serverIp = argv[1];
    int port = atoi(argv[2]);

    clientMain(serverIp, port);

    WSACleanup(); // Add this line to clean up Winsock after the client finishes its work

    return 0;
}